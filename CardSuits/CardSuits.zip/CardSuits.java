package OOPJavaAdvanced.CardSuits;

public enum CardSuits {
    CLUBS, DIAMONDS, HEARTS, SPADES;


}
