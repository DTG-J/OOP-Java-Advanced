package handball.entities.equipment;

public class ElbowPad extends BaseEquipment{
    public ElbowPad() {
        super(90, 25);
    }
}
