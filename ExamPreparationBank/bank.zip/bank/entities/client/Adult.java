package bank.entities.client;

public class Adult extends BaseClient{
    @Override
    public void increase() {

    }

    public Adult(String name, String ID, double income) {
        super(name, ID, 4, income);
    }
}
