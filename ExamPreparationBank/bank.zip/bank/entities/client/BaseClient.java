package bank.entities.client;

public abstract class BaseClient implements Client{
    private String name;
    private String ID;
    private  int interest;
    private  double income;

    protected BaseClient(String name, String ID, int interest, double income) {
        this.name = name;
        this.ID = ID;
        this.interest = interest;
        this.income = income;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public void setName(String name) {

    }

    @Override
    public int getInterest() {
        return 0;
    }

    @Override
    public double getIncome() {
        return 0;
    }
}
