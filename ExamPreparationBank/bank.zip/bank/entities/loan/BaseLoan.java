package bank.entities.loan;

public  abstract class BaseLoan implements Loan{
    private int interestRate;
    private double amount;

    protected BaseLoan(int interestRate, double amount) {
        this.interestRate = interestRate;
        this.amount = amount;
    }

    @Override
    public int getInterestRate() {
        return 0;
    }

    @Override
    public double getAmount() {
        return 0;
    }
}
