package bank.entities.loan;

public abstract class StudentLoan extends BaseLoan{

    public StudentLoan() {
        super(1, 10_000);
    }
}
