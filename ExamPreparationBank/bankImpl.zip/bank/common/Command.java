package bank.common;

public enum Command {
    AddBank,
    AddLoan,
    ReturnedLoan,
    AddClient,
    FinalCalculation,
    Statistics,
    End
}
