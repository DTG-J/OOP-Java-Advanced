package bank.entities.bank;

public class BranchBank extends BaseBank{
    public BranchBank(String name) {
        super(name, 25);
    }
}
