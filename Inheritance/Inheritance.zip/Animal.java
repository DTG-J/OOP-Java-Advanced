package OOPJavaAdvanced.Java_OOP_Inheritance_Lab;

public class Animal {
    public void eat (){
        System.out.println("eating...");
    }
}
