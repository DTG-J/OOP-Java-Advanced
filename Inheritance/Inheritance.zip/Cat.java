package OOPJavaAdvanced.Java_OOP_Inheritance_Lab;

public class Cat extends Animal{
    public void meow (){
        System.out.println("meowing...");
    }
}
