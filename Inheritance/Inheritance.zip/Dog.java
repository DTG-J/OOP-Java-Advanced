package OOPJavaAdvanced.Java_OOP_Inheritance_Lab;

public class Dog extends Animal{
    public void bark (){
        System.out.println("barking...");
    }

}