package OOPJavaAdvanced.Java_OOP_Inheritance_Lab;

import OOPJavaAdvanced.CardSuits.CardSuits;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat ();
        dog.bark();

        Cat cat = new Cat();
        cat.eat();
        cat.meow();
    }
}
