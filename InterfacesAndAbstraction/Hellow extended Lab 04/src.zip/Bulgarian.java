public class Bulgarian extends BasePerson{
    public Bulgarian(String name) {
        super(name);

    }

    @Override
    public String sayHellow() {
        return "Здравей";
    }
}
