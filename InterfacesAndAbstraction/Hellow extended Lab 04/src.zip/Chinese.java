public class Chinese extends BasePerson{
     public Chinese(String name) {
       super(name);

    }

    @Override
    public String sayHellow() {
        return "Djydjybydjy";
    }
}
