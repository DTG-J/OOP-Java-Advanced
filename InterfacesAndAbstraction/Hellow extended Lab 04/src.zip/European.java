public class European extends BasePerson{

    public European(String name) {
        super(name);
    }

    @Override
    public String sayHellow() {
        return "Hellow";
    }
}
