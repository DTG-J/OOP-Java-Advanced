public interface Person {
    String getName ();
    String sayHellow ();

}
