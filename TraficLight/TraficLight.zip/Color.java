package OOPJavaAdvanced.TraficLight;

public enum Color {
    RED,
    GREEN,
    YELLOW;

}
